package com.kadeprime.novelwriter;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private File workspaceFile;
    private Runnable pendingSave;
    private volatile String latestWorkspaceJson;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        workspaceFile = new File(getFilesDir(), "novels-workspace.json");

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(243, 236, 224));
        window.setNavigationBarColor(Color.rgb(250, 246, 237));
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(250, 246, 237));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        applySystemBarInsets();
        configureWebView();
        loadLocalApp();
    }

    private void applySystemBarInsets() {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;

            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsets wi = insets;
                int mask = WindowInsets.Type.statusBars()
                        | WindowInsets.Type.navigationBars()
                        | WindowInsets.Type.displayCutout();
                android.graphics.Insets bars = wi.getInsets(mask);
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }

            webView.setPadding(0, top, 0, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus(View.FOCUS_DOWN);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(Color.rgb(250, 246, 237));

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep local app navigation inside the WebView.
                if (url == null) return false;
                if (url.startsWith("file:///android_asset/")
                        || url.startsWith("about:blank")) {
                    return false;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                } catch (ActivityNotFoundException ignored) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = callback;

                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, 4101);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidStorageBridge(), "AndroidStorage");
    }

    private void loadLocalApp() {
        ioExecutor.execute(() -> {
            try {
                String html;
                try (InputStream in = getAssets().open("index.html")) {
                    html = readUtf8(in);
                }

                if (!workspaceFile.exists()) {
                    try (InputStream in = getAssets().open("novels-workspace.json")) {
                        String seed = readUtf8(in);
                        writeAtomic(seed);
                    }
                }

                String workspace = readUtf8(new FileInputStream(workspaceFile));
                String replacement = "<script id=\"novel-writer-embedded-data\" type=\"application/json\">\n"
                        + workspace
                        + "\n</script>";

                java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                        "<script id=\"novel-writer-embedded-data\"[^>]*>[\\s\\S]*?</script>",
                        java.util.regex.Pattern.CASE_INSENSITIVE
                );
                java.util.regex.Matcher m = p.matcher(html);
                if (m.find()) {
                    html = m.replaceFirst(java.util.regex.Matcher.quoteReplacement(replacement));
                }

                final String page = html;
                mainHandler.post(() ->
                        webView.loadDataWithBaseURL(
                                "file:///android_asset/",
                                page,
                                "text/html",
                                "UTF-8",
                                null
                        )
                );
            } catch (Exception e) {
                mainHandler.post(() -> webView.loadDataWithBaseURL(
                        "file:///android_asset/",
                        "<html><body style='padding:24px;font-family:sans-serif'>"
                                + "<h3>Novel Writer could not start</h3><pre>"
                                + escapeHtml(e.toString())
                                + "</pre></body></html>",
                        "text/html",
                        "UTF-8",
                        null
                ));
            }
        });
    }

    private static String readUtf8(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toString(StandardCharsets.UTF_8.name());
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private synchronized void scheduleSave(String json) {
        latestWorkspaceJson = json;
        if (pendingSave != null) mainHandler.removeCallbacks(pendingSave);
        pendingSave = () -> {
            final String snapshot = latestWorkspaceJson;
            ioExecutor.execute(() -> {
                try {
                    writeAtomic(snapshot);
                } catch (Exception ignored) {
                }
            });
            pendingSave = null;
        };
        mainHandler.postDelayed(pendingSave, 700);
    }

    private synchronized void flushSave() {
        if (pendingSave != null) {
            mainHandler.removeCallbacks(pendingSave);
            pendingSave = null;
        }
        final String snapshot = latestWorkspaceJson;
        if (snapshot != null) {
            ioExecutor.execute(() -> {
                try {
                    writeAtomic(snapshot);
                } catch (Exception ignored) {
                }
            });
        }
    }

    private void writeAtomic(String json) throws Exception {
        File tmp = new File(getFilesDir(), "novels-workspace.json.tmp");
        try (FileOutputStream out = new FileOutputStream(tmp, false)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        }

        if (Build.VERSION.SDK_INT >= 26) {
            Files.move(tmp.toPath(), workspaceFile.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
        } else {
            if (!tmp.renameTo(workspaceFile)) {
                try (FileOutputStream out = new FileOutputStream(workspaceFile, false)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    out.getFD().sync();
                }
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
    }

    public class AndroidStorageBridge {
        @JavascriptInterface
        public boolean saveWorkspace(String json) {
            if (json == null) return false;
            scheduleSave(json);
            return true;
        }

        @JavascriptInterface
        public String getWorkspace() {
            try {
                return readUtf8(new FileInputStream(workspaceFile));
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public String getStorageLocation() {
            return workspaceFile.getAbsolutePath();
        }

        @JavascriptInterface
        public long getWorkspaceSize() {
            return workspaceFile.exists() ? workspaceFile.length() : 0L;
        }

        @JavascriptInterface
        public boolean flushWorkspace() {
            // The last scheduled save is deliberately asynchronous.
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4101 && fileChooserCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileChooserCallback.onReceiveValue(results);
            fileChooserCallback = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        flushSave();
    }

    @Override
    protected void onDestroy() {
        flushSave();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidStorage");
            webView.stopLoading();
            webView.destroy();
        }
        ioExecutor.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
