# Novel Writer Android v1.4.0

This build fixes a critical JavaScript MutationObserver loop in the global Reading Mode helper. The previous observer watched the entire document and then mutated the Reading Mode button, which could continuously schedule observer callbacks and make the React UI appear responsive while JavaScript actions were delayed or not visibly committed.

v1.4 changes:
- Reading Mode observer only repairs the button when it is missing.
- Removed React StrictMode wrapper to reduce duplicate effect behavior in the embedded WebView.
- Android workspace writes are debounced and performed on a background executor, not synchronously on the WebView/UI thread.
- Android system bar insets are applied directly to the WebView so status/notification and navigation areas are not covered.
- App remains responsive across portrait/landscape and phone/tablet sizes.
- Existing workspace file remains a single canonical app-private file.
