# Novel Writer Android 1.1.0

This project packages the supplied Novel Writer HTML as an offline Android WebView app.

## Important storage behavior
- The app keeps exactly one canonical workspace file: `novels-workspace.json` in Android app-private storage.
- Edits are automatically saved after a short idle period and flushed when the app pauses/closes.
- Saves replace the same file; they do NOT create `novels-workspace (1).json`, ` (2)`, etc.
- A temporary `.tmp` file exists only during the atomic write and is removed after completion/failure.
- Explicit exports such as EPUB/TXT/ZIP remain separate exported files by design.
- Uninstalling the app removes app-private storage, so use the app's export features for a backup.

## Build
Open this folder in Android Studio and let Gradle sync. Use `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
The generated debug APK will be under `app/build/outputs/apk/debug/`.

The build targets compileSdk 35, minSdk 29 (Android 10+), targetSdk 35.


## Responsive Android build v1.2.0
This build targets Android SDK 34 to keep content inside system bars on Android 15+, while compiling with SDK 35. The WebView uses a fixed app viewport; only chapter manuscript text scrolls, with responsive phone/tablet controls.
