package com.kadeprime.novelwriter;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class MainActivity extends Activity {
    private static final String WORKSPACE_FILE = "novels-workspace.json";
    private static final int FILE_CHOOSER = 401;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String pendingWorkspace;

    private final Runnable saveRunnable = new Runnable() {
        @Override public void run() {
            String data;
            synchronized (MainActivity.this) {
                data = pendingWorkspace;
                pendingWorkspace = null;
            }
            if (data != null) writeWorkspaceAtomic(data);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);

        configureSystemBars();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(250, 246, 237));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        configureWebView();
        setContentView(webView);

        ensureWorkspaceFile();
        loadLocalApp();
        handleIncomingIntent(getIntent());
    }

    private void configureSystemBars() {
        Window window = getWindow();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true);
        }
        window.setStatusBarColor(Color.rgb(243, 236, 224));
        window.setNavigationBarColor(Color.rgb(250, 246, 237));

        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
        }

        int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(
                    WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidStorageBridge(), "AndroidStorage");
    }

    private void loadLocalApp() {
        try {
            String html = readUtf8Asset("index.html");
            String json = readWorkspace();

            if (json != null && !json.trim().isEmpty()) {
                String marker = "<script id=\"novel-writer-embedded-data\" type=\"application/json\">";
                int a = html.indexOf(marker);
                if (a >= 0) {
                    int contentStart = a + marker.length();
                    int b = html.indexOf("</script>", contentStart);
                    if (b > contentStart) {
                        html = html.substring(0, contentStart)
                                + "\n" + json + "\n"
                                + html.substring(b);
                    }
                }
            }

            webView.loadDataWithBaseURL(
                    "file:///android_asset/",
                    html,
                    "text/html",
                    "UTF-8",
                    "file:///android_asset/index.html"
            );
        } catch (Exception e) {
            Toast.makeText(this,
                    "Could not load Novel Writer: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void ensureWorkspaceFile() {
        File f = new File(getFilesDir(), WORKSPACE_FILE);
        if (f.exists() && f.length() > 0) return;

        try {
            writeWorkspaceAtomic(readUtf8Asset("novels-workspace.json"));
        } catch (Exception e) {
            Toast.makeText(this,
                    "Workspace initialization failed",
                    Toast.LENGTH_LONG).show();
        }
    }

    private String readWorkspace() {
        File f = new File(getFilesDir(), WORKSPACE_FILE);
        if (!f.exists()) return null;
        try {
            return readAll(new FileInputStream(f));
        } catch (Exception e) {
            return null;
        }
    }

    private String readUtf8Asset(String name) throws Exception {
        return readAll(getAssets().open(name));
    }

    private String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private boolean writeWorkspaceAtomic(String json) {
        if (json == null) return false;

        File target = new File(getFilesDir(), WORKSPACE_FILE);
        File tmp = new File(getFilesDir(), WORKSPACE_FILE + ".tmp");

        try {
            FileOutputStream out = new FileOutputStream(tmp, false);
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
            out.close();

            try {
                Files.move(tmp.toPath(), target.toPath(),
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception atomicFailure) {
                if (target.exists() && !target.delete()) {
                    throw new Exception("Unable to replace old workspace");
                }
                if (!tmp.renameTo(target)) {
                    throw new Exception("Unable to finalize workspace");
                }
            }
            return true;
        } catch (Exception e) {
            tmp.delete();
            return false;
        }
    }

    private synchronized void queueSave(String json) {
        pendingWorkspace = json;
        handler.removeCallbacks(saveRunnable);
        handler.postDelayed(saveRunnable, 900);
    }

    private synchronized void flushSave() {
        handler.removeCallbacks(saveRunnable);
        String data = pendingWorkspace;
        pendingWorkspace = null;
        if (data != null) writeWorkspaceAtomic(data);
    }

    public class AndroidStorageBridge {
        @JavascriptInterface
        public boolean saveWorkspace(String json) {
            if (json == null || json.trim().isEmpty()) return false;
            queueSave(json);
            return true;
        }

        @JavascriptInterface
        public String getWorkspace() {
            String json = readWorkspace();
            return json == null ? "" : json;
        }

        @JavascriptInterface
        public long getWorkspaceSize() {
            File f = new File(getFilesDir(), WORKSPACE_FILE);
            return f.exists() ? f.length() : 0L;
        }

        @JavascriptInterface
        public String getStorageLocation() {
            return new File(getFilesDir(), WORKSPACE_FILE).getAbsolutePath();
        }

        @JavascriptInterface
        public void flushWorkspace() {
            flushSave();
        }

        @JavascriptInterface
        public String platform() {
            return "android";
        }
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        webView.postDelayed(() -> {
            String encoded = JSONObjectQuote(uri.toString());
            webView.evaluateJavascript(
                    "window.__nwAndroidOpenUri && window.__nwAndroidOpenUri(" + encoded + ")",
                    null
            );
        }, 800);
    }

    private String JSONObjectQuote(String value) {
        return "\"" + value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n") + "\"";
    }

    @Override protected void onPause() {
        flushSave();
        super.onPause();
    }

    @Override protected void onDestroy() {
        flushSave();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    @Override protected void onActivityResult(
            int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER && fileChooserCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileChooserCallback.onReceiveValue(result);
            fileChooserCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
