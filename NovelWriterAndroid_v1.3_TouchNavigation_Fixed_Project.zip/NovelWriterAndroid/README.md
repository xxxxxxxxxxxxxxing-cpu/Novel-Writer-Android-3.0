# Novel Writer Android v1.3.0 — Touch/Navigation Fixed

This build is based on the original working Novel Writer HTML. It preserves the full React application bootstrap
and adds Android-native persistent workspace storage plus responsive Android layout.

Important fix: the previous Android-modified HTML accidentally inserted extra HTML script tags into the JavaScript
bundle's EPUB-export template, which prevented the React application bootstrap (`createRoot(...)`) from executing
in WebView. The result was a static snapshot: scrolling and native text selection worked, but React button handlers
did not. This version keeps the original bundle intact and adds Android changes only at safe HTML boundaries.

Storage:
- One canonical app-private novels-workspace.json is updated in place.
- No numbered duplicate workspace files are created.
- Uninstalling the app removes app-private storage; use EPUB/TXT/ZIP export for backups.

UI:
- Android status/navigation bars are handled by the native Activity.
- Fixed app viewport.
- Manuscript text area is the scrollable editor region.
- Navigation/header/footer controls remain outside the manuscript scroll.
- Responsive phone/tablet and portrait/landscape sizing.
