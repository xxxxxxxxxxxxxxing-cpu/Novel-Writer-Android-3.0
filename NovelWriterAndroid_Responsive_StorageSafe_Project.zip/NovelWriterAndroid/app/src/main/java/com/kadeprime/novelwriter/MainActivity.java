package com.kadeprime.novelwriter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class MainActivity extends Activity {
    private static final String WORKSPACE_FILE = "novels-workspace.json";
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String pendingWorkspace = null;
    private final Runnable saveRunnable = new Runnable() {
        @Override public void run() {
            String data;
            synchronized (this) { data = pendingWorkspace; pendingWorkspace = null; }
            if (data != null) writeWorkspaceAtomic(data);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(250, 246, 237));
        setContentView(webView);
        configureSystemBars();
        configureWebView();
        ensureWorkspaceFile();
        loadLocalApp();
        handleIncomingIntent(getIntent());
    }


    private void configureSystemBars() {
        Window window = getWindow();
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep the WebView
        // adaptive, but inset the actual WebView content so controls never sit
        // under the notification/status or navigation bars.
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
        }
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(),
                        insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),
                        insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        webView.requestApplyInsets();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, 2001); }
                catch (Exception e) { fileChooserCallback = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidStorageBridge(), "AndroidStorage");
    }

    private void loadLocalApp() {
        try {
            String html = readUtf8Asset("index.html");
            String json = readWorkspace();
            if (json != null && !json.trim().isEmpty()) {
                String start = "<script id=\"novel-writer-embedded-data\" type=\"application/json\">";
                int a = html.indexOf(start);
                if (a >= 0) {
                    int contentStart = a + start.length();
                    int b = html.indexOf("</script>", contentStart);
                    if (b > contentStart) {
                        html = html.substring(0, contentStart) + "\n" + json + "\n" + html.substring(b);
                    }
                }
            }
            webView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", "file:///android_asset/index.html");
        } catch (Exception e) {
            Toast.makeText(this, "Could not load Novel Writer: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String readUtf8Asset(String name) throws Exception {
        InputStream in = getAssets().open(name);
        return readAll(in);
    }

    private String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private void ensureWorkspaceFile() {
        File f = new File(getFilesDir(), WORKSPACE_FILE);
        if (f.exists() && f.length() > 0) return;
        try {
            String json = readUtf8Asset("novels-workspace.json");
            writeWorkspaceAtomic(json);
        } catch (Exception e) { Toast.makeText(this, "Workspace initialization failed", Toast.LENGTH_LONG).show(); }
    }

    private String readWorkspace() {
        File f = new File(getFilesDir(), WORKSPACE_FILE);
        if (!f.exists()) return null;
        try { return readAll(new FileInputStream(f)); } catch (Exception e) { return null; }
    }

    private boolean writeWorkspaceAtomic(String json) {
        if (json == null) return false;
        File dir = getFilesDir();
        File target = new File(dir, WORKSPACE_FILE);
        File tmp = new File(dir, WORKSPACE_FILE + ".tmp");
        try {
            FileOutputStream out = new FileOutputStream(tmp, false);
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
            out.close();
            try {
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception atomicFailure) {
                // Fallback for filesystems that do not support atomic replace.
                if (target.exists() && !target.delete()) throw new Exception("Unable to replace old workspace");
                if (!tmp.renameTo(target)) throw new Exception("Unable to finalize workspace");
            }
            return true;
        } catch (Exception e) {
            tmp.delete();
            return false;
        }
    }

    private void queueSave(String json) {
        synchronized (saveRunnable) { pendingWorkspace = json; }
        handler.removeCallbacks(saveRunnable);
        handler.postDelayed(saveRunnable, 900);
    }

    private void flushSave() {
        handler.removeCallbacks(saveRunnable);
        String data;
        synchronized (saveRunnable) { data = pendingWorkspace; pendingWorkspace = null; }
        if (data != null) writeWorkspaceAtomic(data);
    }

    public class AndroidStorageBridge {
        @JavascriptInterface public boolean saveWorkspace(String json) {
            queueSave(json);
            return true;
        }
        @JavascriptInterface public String getWorkspace() { return readWorkspace(); }
        @JavascriptInterface public long getWorkspaceSize() {
            File f = new File(getFilesDir(), WORKSPACE_FILE);
            return f.exists() ? f.length() : 0L;
        }
        @JavascriptInterface public String getStorageLocation() { return "App private storage / " + WORKSPACE_FILE; }
        @JavascriptInterface public boolean flushWorkspace() { flushSave(); return true; }
    }

    private void handleIncomingIntent(Intent intent) {
        // The HTML app already provides its own import UI. This activity keeps the
        // intent filters so files can be handed to the app; WebView file chooser is
        // the normal import path and does not silently overwrite the workspace.
    }

    @Override protected void onPause() { flushSave(); super.onPause(); }
    @Override protected void onDestroy() { flushSave(); if (webView != null) webView.destroy(); super.onDestroy(); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 2001 && fileChooserCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
            fileChooserCallback.onReceiveValue(results);
            fileChooserCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
