# Novel Writer Android v1.5.0

This build is based on the uploaded working APK's HTML and fixes the Android WebView integration without replacing the app's React navigation.

Fixes:
- Android system-bar insets applied as WebView padding.
- Whole document fixed; only manuscript and intended lists scroll.
- Manuscript textarea expands to the available height instead of being fixed at 450px.
- Native Android folder picker is exposed as a Directory Picker-compatible bridge.
- Linked folder URI/name persist across app restarts.
- Native folder read/write/delete/list operations support the existing folder workspace code.
- Native workspace saves remain one canonical app-private JSON file and are asynchronous/debounced.
- File import remains supported through WebView file chooser.

Build:
- Gradle 8.10.2
- Android Gradle Plugin 8.6.1
- compileSdk 35
- targetSdk 35
- minSdk 29
- version 1.5.0, versionCode 7

GitHub Actions extraction:
unzip -o NovelWriterAndroid_v1.5_AndroidFolder_Layout_Fix_Project.zip
