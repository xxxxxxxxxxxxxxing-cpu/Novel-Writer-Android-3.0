package com.kadeprime.novelwriter;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.webkit.*;
import android.view.*;
import android.graphics.Color;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private File workspaceFile;
    private volatile String pendingWorkspace = null;
    private volatile boolean saveScheduled = false;
    private static final int REQ_FOLDER = 7001;
    private Uri pickedFolderUri;
    private final android.content.SharedPreferences prefs() {
        return getSharedPreferences("novel_writer_android", MODE_PRIVATE);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        getWindow().setStatusBarColor(Color.rgb(247,242,232));
        getWindow().setNavigationBarColor(Color.rgb(247,242,232));
        if (Build.VERSION.SDK_INT >= 23)
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= 26)
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        workspaceFile = new File(getFilesDir(), "novels-workspace.json");

        webView = new WebView(this);
        configureWebView();
        setContentView(webView);

        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets x = insets.getInsets(WindowInsets.Type.systemBars()
                    | WindowInsets.Type.displayCutout());
                top = x.top;
                bottom = x.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            // Keep the whole HTML viewport out of Android's system bars.
            v.setPadding(0, top, 0, bottom);
            return insets;
        });
        ViewCompatShim.requestInsets(webView);

        loadLocalApp();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);

        webView.setBackgroundColor(Color.rgb(247,242,232));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                    FileChooserParams params) {
                Intent i;
                try { i = params.createIntent(); }
                catch(Exception e) {
                    i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                }
                try { startActivityForResult(i, 7002); }
                catch(Exception e) { cb.onReceiveValue(null); return false; }
                fileCallback = cb;
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidStorage(), "AndroidStorage");
    }

    private ValueCallback<Uri[]> fileCallback;

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_FOLDER) {
            if (result == RESULT_OK && data != null && data.getData() != null) {
                pickedFolderUri = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(pickedFolderUri, flags);
                } catch(Exception ignored) {}
            }
            return;
        }
        if (request == 7002 && fileCallback != null) {
            Uri[] resultUris = null;
            if (result == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    resultUris = new Uri[n];
                    for(int i=0;i<n;i++) resultUris[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) resultUris = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(resultUris);
            fileCallback = null;
        }
    }

    private void loadLocalApp() {
        io.execute(() -> {
            try {
                if (!workspaceFile.exists()) {
                    try (InputStream in = getAssets().open("novels-workspace.json");
                         OutputStream out = new FileOutputStream(workspaceFile)) {
                        byte[] buf = new byte[8192]; int n;
                        while((n=in.read(buf))>0) out.write(buf,0,n);
                    }
                }
                String html = readAsset("index.html");
                String ws = readText(workspaceFile);
                html = replaceEmbeddedWorkspace(html, ws);
                final String page = html;
                main.post(() -> webView.loadDataWithBaseURL(
                    "file:///android_asset/", page, "text/html", "UTF-8", null));
            } catch(Exception e) {
                main.post(() -> Toast.makeText(this, "Failed to load Novel Writer: "+e.getMessage(),
                    Toast.LENGTH_LONG).show());
            }
        });
    }

    private String readAsset(String n) throws IOException {
        try(InputStream in=getAssets().open(n)) {
            ByteArrayOutputStream b=new ByteArrayOutputStream();
            byte[] x=new byte[8192]; int k;
            while((k=in.read(x))>0)b.write(x,0,k);
            return b.toString("UTF-8");
        }
    }
    private String readText(File f) throws IOException {
        return new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }
    private String replaceEmbeddedWorkspace(String html,String ws) {
        String marker="<script id=\"novel-writer-embedded-data\" type=\"application/json\">";
        int a=html.indexOf(marker);
        if(a<0)return html;
        int s=a+marker.length(), e=html.indexOf("</script>",s);
        if(e<0)return html;
        return html.substring(0,s)+"\n"+ws+"\n"+html.substring(e);
    }

    public class AndroidStorage {
        @JavascriptInterface public boolean saveWorkspace(String json) {
            pendingWorkspace=json;
            if(!saveScheduled) {
                saveScheduled=true;
                main.postDelayed(() -> {
                    String data=pendingWorkspace; pendingWorkspace=null; saveScheduled=false;
                    io.execute(() -> atomicWrite(workspaceFile,data));
                }, 700);
            }
            return true;
        }
        @JavascriptInterface public String getWorkspace() {
            try{return readText(workspaceFile);}catch(Exception e){return "[]";}
        }
        @JavascriptInterface public long getWorkspaceSize() { return workspaceFile.length(); }
        @JavascriptInterface public String getStorageLocation() { return workspaceFile.getAbsolutePath(); }
        @JavascriptInterface public void flushWorkspace() {
            String data=pendingWorkspace; pendingWorkspace=null; saveScheduled=false;
            if(data!=null) io.execute(() -> atomicWrite(workspaceFile,data));
        }

        @JavascriptInterface public void pickFolder() {
            main.post(() -> {
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                           Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                           Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                           Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                try { startActivityForResult(i,REQ_FOLDER); }
                catch(Exception e){ Toast.makeText(MainActivity.this,"Folder picker unavailable",Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public String getPickedFolderUri() {
            return pickedFolderUri==null ? "" : pickedFolderUri.toString();
        }
        @JavascriptInterface public String getPickedFolderName() {
            return pickedFolderUri==null ? "" : displayName(pickedFolderUri);
        }
        @JavascriptInterface public void clearPickedFolder() { pickedFolderUri=null; }
        @JavascriptInterface public void setLinkedFolder(String uri,String name) {
            prefs().edit().putString("folder_uri",uri).putString("folder_name",name==null?"Project Folder":name).apply();
        }
        @JavascriptInterface public String getLinkedFolderUri() {
            return prefs().getString("folder_uri","");
        }
        @JavascriptInterface public String getLinkedFolderName() {
            return prefs().getString("folder_name","Project Folder");
        }
        @JavascriptInterface public void clearLinkedFolder() {
            prefs().edit().remove("folder_uri").remove("folder_name").apply();
        }

        @JavascriptInterface public String folderChildUri(String parent,String name,boolean create) {
            try {
                Uri p=Uri.parse(parent); Uri found=findChild(p,name);
                if(found!=null)return found.toString();
                if(create){
                    String mime=DocumentsContract.Document.MIME_TYPE_DIR;
                    Uri u=DocumentsContract.createDocument(getContentResolver(),p,mime,name);
                    return u==null?"":u.toString();
                }
            }catch(Exception e){}
            return "";
        }
        @JavascriptInterface public String fileChildUri(String parent,String name,boolean create) {
            try {
                Uri p=Uri.parse(parent); Uri found=findChild(p,name);
                if(found!=null)return found.toString();
                if(create){
                    String mime=name.toLowerCase(Locale.ROOT).endsWith(".html")?"text/html":"text/plain";
                    Uri u=DocumentsContract.createDocument(getContentResolver(),p,mime,name);
                    return u==null?"":u.toString();
                }
            }catch(Exception e){}
            return "";
        }
        @JavascriptInterface public String listFolderEntries(String parent) {
            JSONArray a=new JSONArray();
            try {
                Uri tree=Uri.parse(parent);
                String id=DocumentsContract.getDocumentId(tree);
                Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
                String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE};
                try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
                    if(c!=null)while(c.moveToNext()){
                        String id2=c.getString(0), n=c.getString(1), mime=c.getString(2);
                        JSONObject o=new JSONObject();
                        o.put("name",n); o.put("kind",DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)?"directory":"file");
                        o.put("uri",DocumentsContract.buildDocumentUriUsingTree(tree,id2).toString());
                        a.put(o);
                    }
                }
            }catch(Exception e){}
            return a.toString();
        }
        @JavascriptInterface public boolean removeFolderEntry(String parent,String name,boolean recursive) {
            try {
                Uri u=findChild(Uri.parse(parent),name);
                return u!=null && DocumentsContract.deleteDocument(getContentResolver(),u);
            }catch(Exception e){return false;}
        }
        @JavascriptInterface public void writeFile(String uri,String data) {
            try {
                Uri u=Uri.parse(uri);
                try(OutputStream out=getContentResolver().openOutputStream(u,"wt")) {
                    if(out!=null)out.write(data.getBytes(StandardCharsets.UTF_8));
                }
            }catch(Exception e){}
        }
        @JavascriptInterface public String readFile(String uri) {
            try(InputStream in=getContentResolver().openInputStream(Uri.parse(uri))) {
                ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] x=new byte[8192]; int n;
                while((n=in.read(x))>0)b.write(x,0,n);
                return b.toString("UTF-8");
            }catch(Exception e){return "";}
        }
        private Uri findChild(Uri parent,String name) {
            String id=DocumentsContract.getDocumentId(parent);
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,id);
            String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME};
            try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
                if(c!=null)while(c.moveToNext()) {
                    if(name.equals(c.getString(1)))
                        return DocumentsContract.buildDocumentUriUsingTree(parent,c.getString(0));
                }
            }catch(Exception e){}
            return null;
        }
        private String displayName(Uri u) {
            try(android.database.Cursor c=getContentResolver().query(u,
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
                if(c!=null&&c.moveToFirst())return c.getString(0);
            }catch(Exception ignored){}
            return "Project Folder";
        }
    }

    private void atomicWrite(File f,String data) {
        if(data==null)return;
        File tmp=new File(f.getParentFile(),f.getName()+".tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)) {
            out.write(data.getBytes(StandardCharsets.UTF_8)); out.flush(); out.getFD().sync();
            if(Build.VERSION.SDK_INT>=26) {
                java.nio.file.Files.move(tmp.toPath(),f.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } else {
                if(f.exists())f.delete();
                if(!tmp.renameTo(f))throw new IOException("rename failed");
            }
        }catch(Exception e){ try{tmp.delete();}catch(Exception ignored){} }
    }

    @Override protected void onPause(){ super.onPause(); flushNative(); }
    @Override protected void onDestroy(){ flushNative(); io.shutdownNow(); super.onDestroy(); }
    private void flushNative(){
        if(webView!=null) webView.evaluateJavascript(
            "(function(){try{window.AndroidStorage&&window.AndroidStorage.flushWorkspace()}catch(e){}})();",null);
    }

    static class ViewCompatShim {
        static void requestInsets(View v){
            if(Build.VERSION.SDK_INT>=20) v.requestApplyInsets();
        }
    }
}
